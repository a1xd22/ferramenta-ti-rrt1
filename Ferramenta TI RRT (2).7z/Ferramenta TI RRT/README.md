🖥️ Ferramenta de Manutenção do Windows






Um poderoso kit de ferramentas de manutenção do Windows, tudo-em-um, feito inteiramente em Batch & PowerShell.
Projetado para usuários avançados, administradores de sistemas e curiosos – agora mais inteligente, seguro e totalmente compatível com uso offline.

📸 Captura de tela
<img width="945" height="685" alt="Windows Maintenance Tool Screenshot" src="https://github.com/user-attachments/assets/f7cbc263-b6d0-47f8-af70-ef20b352924d" />
✅ Recursos

Executar ferramentas de reparo essenciais:

Acesso rápido ao SFC, DISM e CHKDSK para reparos básicos do Windows

Otimização de SSDs:

TRIM e desfragmentação compatível para unidades mais rápidas e saudáveis

Gerenciamento de atualizações do Windows:

Use o winget para instalar, atualizar e reparar pacotes do sistema

Instala automaticamente o winget caso não esteja presente

Manipulação flexível de pacotes: visualizar, pesquisar e atualizar aplicativos/pacotes individualmente informando o ID

Melhoria na v3.6.0: Ferramenta de reparo do Windows Update agora com suporte a reconstrução total e mais opções de reparo

Diagnóstico e reparo de rede:

Inclui ipconfig, visualizador de tabela de roteamento, configuração de DNS, redefinição de adaptadores e mais

Limpeza de privacidade e arquivos temporários:

Excluir arquivos temporários, logs e cache de navegadores

Limpeza de privacidade para rastros extras (histórico, cookies etc.)

Salvar relatórios detalhados:

Exportar informações do sistema, rede e lista de drivers para a Área de Trabalho ou pasta personalizada

Ferramentas de Registro:

Limpeza segura, backup e verificação de corrupção

Limpeza de registro com menu estável:

Lista de entradas “seguras para excluir” (IE40, IE4Data, DirectDrawEx etc.)

Exclusão em massa de todas as entradas seguras

Backup e restauração fáceis com arquivos .reg versionados

Gerenciamento de DNS-Adblock:

Bloqueio de domínios de anúncios/rastreamento pelo arquivo hosts (adblock/mirrors incluídos)

Melhor tratamento de arquivos bloqueados, mensagens mais claras, múltiplos backups/restaurações

Gerenciador de Firewall:

Gerenciador de Firewall integrado via PowerShell, baseado em menu

Criar regras, ativar/desativar Firewall do Windows diretamente pela ferramenta

Configurações .NET RollForward (Novo na v3.6.0):

Permite ao sistema usar uma versão específica do .NET (SDK/runtime)

Reduz a necessidade de instalar várias versões do .NET

Reparador de Atalhos (Novo na v3.6.0):

Reparo automático de atalhos quebrados

Menu reorganizado (opções 30 e 0 movidas para o final para melhor estrutura)

Menu amigável e baseado em opções:

Mais opções de retorno ao menu (v3.6.0)

Todas as funções acessíveis a partir de um menu principal simples – sem necessidade de experiência em PowerShell

Suporte/ajuda, contato por Discord/GitHub acessível com uma tecla

Portátil e seguro:

Pode ser executado via USB, sem instalação ou implantação administrativa

Sem dependências de terceiros ou downloads da internet (exceto winget, opcional)

⚙️ Instalação

Inicie Start_Windows_Maintenance_Tool.bat.

Siga o menu interativo.

Certifique-se de que Start_Windows_Maintenance_Tool.bat e Windows_Maintenance_Tool.ps1 estejam na mesma pasta.

⚠️ A saída do script pode aparecer no idioma do seu sistema (ex.: inglês, dinamarquês etc.). Isso é normal.

📁 Arquivos de Saída

Salvos diretamente na pasta escolhida (padrão: Área de Trabalho\SystemReports):

System_Info_AAAA-MM-DD.txt – informações completas do sistema

Network_Info_AAAA-MM-DD.txt – configuração detalhada da rede

Driver_List_AAAA-MM-DD.txt – lista de todos os drivers instalados

routing_table_AAAA-MM-DD.txt – tabela de roteamento da rede

RegistryBackup_AAAA-MM-DD_HH-MM.reg – backups do registro com data/hora

🧪 Solução de Problemas & FAQ

P: O script não executou com privilégios de administrador?
R: Para funcionar corretamente, a ferramenta precisa de direitos administrativos.
Clique com o botão direito no .bat e escolha “Executar como administrador”.

Se nada acontecer, verifique se o UAC está ativado e tente novamente.

Executar manualmente no PowerShell, se necessário:

Start-Process powershell -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File 'Caminho\Para\Windows_Maintenance_Tool.ps1'"


P: Por que trava ao selecionar a limpeza do registro?
R: Isso foi corrigido na v3.1.3. Agora a ferramenta lista e exclui chaves de registro de forma segura com backup automático.

P: Por que o Desfragmentador de Registro foi removido?
R: Ele dependia do NTREGOPT, que não está mais disponível. O script agora é totalmente offline e nativo do Windows.


🤝 Contribuindo

Pull requests, issues e feedback são bem-vindos!
Veja CONTRIBUTING.md
 para diretrizes.

🎬 Guias em Vídeo

Guia por a1xd22

Passo a passo por Tiago Henrique
